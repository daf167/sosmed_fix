export default class AddStoryPresenter {
  #view;
  #postStory;
  #capturedBlob = null;

  constructor({ view, postStory }) {
    this.#view = view;
    this.#postStory = postStory;
  }

  initEvents() {
    const form = document.querySelector('#add-story-form');
    const fileInput = document.querySelector('#photo');
    const video = document.querySelector('#camera');
    const canvas = document.querySelector('#canvas');
    const captureButton = document.querySelector('#capture-button');

    captureButton.addEventListener('click', () => {
      const ctx = canvas.getContext('2d');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      canvas.toBlob((blob) => {
        this.#capturedBlob = blob;
        this.#view.showMessage('Foto dari kamera berhasil diambil.');
        fileInput.value = '';
      }, 'image/jpeg');
    });

    fileInput.addEventListener('change', () => {
      if (fileInput.files.length > 0) {
        this.#capturedBlob = null;
        this.#view.showMessage('Foto dari galeri dipilih.');
      }
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const description = document.querySelector('#description').value;
      const photo = this.#capturedBlob || fileInput.files[0];
      const lat = document.getElementById('lat').value;
      const lon = document.getElementById('lon').value;

      if (!photo) {
        this.#view.showMessage('Silakan pilih atau ambil foto terlebih dahulu.');
        return;
      }

      if (!lat || !lon) {
        this.#view.showMessage('Silakan pilih lokasi cerita di peta.');
        return;
      }

      const token = localStorage.getItem('token');
      const response = await this.#postStory({
        description,
        photo,
        lat,
        lon,
        token,
      });

      if (!response.error) {
        this.#view.showMessage('Story berhasil ditambahkan!');
        this.#view.redirectHome();
      } else {
        this.#view.showMessage(`Gagal: ${response.message}`);
      }
    });

    window.addEventListener('hashchange', () => {
      this.#view.stopStream();
    });
  }
}
