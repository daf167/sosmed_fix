import AddStoryPresenter from './add-story-presenter';
import { postStory } from '../../data/api';
import L from 'leaflet';

export default class AddStoryPage {
  #presenter;
  #stream = null;
  #map;
  #marker;

  async render() {
    return `
      <section class="form-section">
        <h2>Tambah Cerita</h2>
        <form id="add-story-form">
          <div>
            <label for="description">Deskripsi</label>
            <textarea id="description" class="form-control" required></textarea>
          </div>

          <div>
            <label for="photo">Ambil dari Galeri</label>
            <input type="file" id="photo" class="form-control" accept="image/*" />
            <small>Atau gunakan kamera di bawah</small>
          </div>

          <div class="camera-container">
            <video id="camera" autoplay muted playsinline style="width: 100%; margin-top: 0.5rem;"></video>
            <button type="button" id="capture-button" class="btn btn-primary" style="margin-top: 0.5rem;">📸 Ambil dari Kamera</button>
            <canvas id="canvas" style="display: none;"></canvas>
          </div>

          <div class="map-container" style="margin-top: 1rem;">
            <label for="mapPicker">Pilih Lokasi Cerita</label>
            <div id="mapPicker" style="height: 300px;"></div>
            <p id="pickedLocation">📍 Belum dipilih</p>
            <input type="hidden" id="lat" name="lat" />
            <input type="hidden" id="lon" name="lon" />
          </div>

          <button type="submit" class="btn btn-primary">📤 Kirim Cerita</button>
        </form>

        <div id="form-message" role="alert" aria-live="polite" style="margin-top: 1rem; color: red;"></div>
      </section>
    `;
  }

  async afterRender() {
    this.#presenter = new AddStoryPresenter({
      view: this,
      postStory,
    });

    this.#initMap();

    try {
      const video = document.querySelector('#camera');
      this.#stream = await navigator.mediaDevices.getUserMedia({ video: true });
      video.srcObject = this.#stream;
    } catch (error) {
      this.showMessage('Gagal mengakses kamera: ' + error.message);
    }

    this.#presenter.initEvents();
  }

  #initMap() {
    const mapContainer = document.getElementById('mapPicker');
    if (!mapContainer) return;

    this.#map = L.map(mapContainer).setView([-2.5, 118], 5); // Indonesia
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: 'Map data © OpenStreetMap contributors',
    }).addTo(this.#map);

    this.#map.on('click', (e) => {
      const { lat, lng } = e.latlng;

      // Update marker
      if (this.#marker) {
        this.#marker.setLatLng([lat, lng]);
      } else {
        this.#marker = L.marker([lat, lng]).addTo(this.#map);
      }

      // Update form
      document.getElementById('lat').value = lat;
      document.getElementById('lon').value = lng;
      document.getElementById('pickedLocation').textContent = `📍 Lokasi dipilih: ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
    });
  }

  stopStream() {
    if (this.#stream) {
      this.#stream.getTracks().forEach(track => track.stop());
      this.#stream = null;
    }
  }

  showMessage(message) {
    const msgContainer = document.getElementById('form-message');
    if (msgContainer) {
      msgContainer.textContent = message;
    }
  }

  redirectHome() {
    this.stopStream();
    window.location.hash = '/';
  }
}
